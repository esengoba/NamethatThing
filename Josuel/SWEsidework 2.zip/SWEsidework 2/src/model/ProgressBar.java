package model;

import javax.swing.*;


public class ProgressBar extends JPanel {


}