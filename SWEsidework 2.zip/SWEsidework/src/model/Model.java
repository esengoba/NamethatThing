package model;

/**
 * Created by elizabethsengoba on 10/19/16.
 */
public class Model {
    private Question newQuestion;
    public Model(){ //Constructor
        //newQuestion = new Question();
    }

    public Question getQuestion(){
        return newQuestion;
    }


}
