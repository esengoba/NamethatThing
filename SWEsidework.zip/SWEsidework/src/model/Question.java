package model;

/**
 * Created by elizabethsengoba on 10/19/16.
 */
public class Question {

        Question(){

        }
        public String getQuestion(){
            //Read in the file from the text

            return "";
        }

}
